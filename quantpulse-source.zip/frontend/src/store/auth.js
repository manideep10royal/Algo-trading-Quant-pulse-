import { create } from "zustand";
import { apiGet, apiPost } from "../lib/api";

export const useAuthStore = create((set, get) => ({
  user: null,
  loading: true,
  setUser: (user) => set({ user, loading: false }),

  checkAuth: async () => {
    // CRITICAL: If returning from OAuth callback, skip the /me check.
    // AuthCallback will exchange the session_id and establish the session first.
    if (window.location.hash?.includes("session_id=")) {
      set({ loading: false });
      return;
    }
    try {
      const user = await apiGet("/auth/me");
      set({ user, loading: false });
    } catch {
      set({ user: null, loading: false });
    }
  },

  logout: async () => {
    try { await apiPost("/auth/logout"); } catch {}
    set({ user: null });
  },
}));
