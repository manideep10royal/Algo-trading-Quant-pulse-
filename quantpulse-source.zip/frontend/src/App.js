import React from "react";
import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { Toaster } from "sonner";
import "./App.css";

import LoginPage from "./pages/LoginPage";
import AuthCallback from "./pages/AuthCallback";
import AppShell from "./components/AppShell";
import DashboardPage from "./pages/DashboardPage";
import MarketPage from "./pages/MarketPage";
import PortfolioPage from "./pages/PortfolioPage";
import StrategyPage from "./pages/StrategyPage";
import SignalsPage from "./pages/SignalsPage";
import PaperTradingPage from "./pages/PaperTradingPage";
import RiskPage from "./pages/RiskPage";
import AIInsightsPage from "./pages/AIInsightsPage";
import HistoryPage from "./pages/HistoryPage";
import SettingsPage from "./pages/SettingsPage";

// CRITICAL: synchronously check for session_id in the URL fragment BEFORE
// any other routing/auth check runs, so we never race the cookie set.
function RouteSwitch() {
  const location = useLocation();
  if (location.hash?.includes("session_id=") || window.location.hash?.includes("session_id=")) {
    return <AuthCallback />;
  }
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="/login" element={<LoginPage />} />
      <Route element={<AppShell />}>
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/market" element={<MarketPage />} />
        <Route path="/portfolio" element={<PortfolioPage />} />
        <Route path="/strategy" element={<StrategyPage />} />
        <Route path="/signals" element={<SignalsPage />} />
        <Route path="/paper-trading" element={<PaperTradingPage />} />
        <Route path="/risk" element={<RiskPage />} />
        <Route path="/ai-insights" element={<AIInsightsPage />} />
        <Route path="/history" element={<HistoryPage />} />
        <Route path="/settings" element={<SettingsPage />} />
      </Route>
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Toaster theme="dark" position="top-right" richColors />
      <RouteSwitch />
    </BrowserRouter>
  );
}

export default App;
