import React, { useState } from "react";
import { apiPost } from "../lib/api";

export default function AIInsightsPage() {
  const [messages, setMessages] = useState([]);
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);

  const send = async () => {
    if (!q.trim()) return;
    const userMsg = { role: "user", text: q };
    setMessages((m) => [...m, userMsg]); setQ(""); setLoading(true);
    try {
      const r = await apiPost("/ai/chat", { question: userMsg.text });
      setMessages((m) => [...m, { role: "ai", text: r.reply }]);
    } catch {
      setMessages((m) => [...m, { role: "ai", text: "(AI temporarily unavailable)" }]);
    } finally { setLoading(false); }
  };

  return (
    <div data-testid="ai-insights-page" className="max-w-3xl">
      <h1 className="text-2xl font-semibold mb-1">AI Insights</h1>
      <p className="text-slate-400 text-sm mb-5">GPT-4o assistant. Ask about indicators, strategies, risk, your data.</p>

      <div className="glass p-5">
        <div className="flex flex-col gap-3 max-h-[460px] overflow-y-auto pr-1" data-testid="chat-window">
          {messages.length === 0 && (
            <div className="text-slate-500 text-sm">Try: "Explain RSI divergence", "When should I use a Bollinger breakout strategy?"</div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={"text-sm p-3 rounded-lg " + (m.role === "user" ? "bg-cyan-500/10 border border-cyan-500/30 self-end max-w-[80%]" : "bg-[#0e1530] border border-[#1f2a4d] self-start max-w-[90%]")}>
              <div className="whitespace-pre-wrap">{m.text}</div>
            </div>
          ))}
          {loading && <div className="text-slate-500 text-xs">GPT-4o thinking…</div>}
        </div>
        <div className="flex gap-2 mt-4">
          <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()}
                 className="input flex-1" placeholder="Ask the AI assistant…" data-testid="chat-input" />
          <button onClick={send} disabled={loading} className="btn-primary" data-testid="chat-send">Send</button>
        </div>
      </div>
    </div>
  );
}
