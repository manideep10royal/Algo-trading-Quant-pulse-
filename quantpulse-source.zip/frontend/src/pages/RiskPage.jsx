import React, { useEffect, useState } from "react";
import { apiGet, apiPut } from "../lib/api";
import { toast } from "sonner";

const FIELDS = [
  { key: "max_risk_per_trade",     label: "Max risk per trade (%)",   step: 0.005, scale: 100 },
  { key: "max_daily_drawdown",     label: "Max daily drawdown (%)",   step: 0.01,  scale: 100 },
  { key: "max_portfolio_exposure", label: "Max portfolio exposure (%)", step: 0.05, scale: 100 },
  { key: "stop_loss_pct",          label: "Default stop-loss (%)",   step: 0.005, scale: 100 },
  { key: "take_profit_pct",        label: "Default take-profit (%)", step: 0.005, scale: 100 },
];

export default function RiskPage() {
  const [rules, setRules] = useState(null);
  useEffect(() => { apiGet("/risk/rules").then(setRules); }, []);

  const save = async () => {
    await apiPut("/risk/rules", rules);
    toast.success("Risk rules saved");
  };

  if (!rules) return <div className="text-slate-400">Loading…</div>;
  return (
    <div data-testid="risk-page">
      <h1 className="text-2xl font-semibold mb-1">Risk Management</h1>
      <p className="text-slate-400 text-sm mb-5">All signals and trades obey these rules before execution.</p>
      <div className="glass p-6 max-w-2xl">
        {FIELDS.map((f) => (
          <div key={f.key} className="mb-4">
            <label className="block text-xs text-slate-500 uppercase tracking-widest mb-1">{f.label}</label>
            <input
              type="number" step={f.step} value={rules[f.key]}
              onChange={(e) => setRules({ ...rules, [f.key]: Number(e.target.value) })}
              className="input w-full"
              data-testid={`risk-input-${f.key}`}
            />
            <div className="text-[11px] text-slate-500 mt-1">= {(rules[f.key] * f.scale).toFixed(2)}%</div>
          </div>
        ))}
        <button onClick={save} className="btn-primary w-full" data-testid="save-risk-rules">Save risk rules</button>
      </div>
    </div>
  );
}
