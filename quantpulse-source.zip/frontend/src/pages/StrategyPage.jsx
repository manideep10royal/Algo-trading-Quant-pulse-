import React, { useEffect, useState } from "react";
import { apiGet, apiPost } from "../lib/api";
import { useNavigate } from "react-router-dom";

export default function StrategyPage() {
  const [strategies, setStrategies] = useState([]);
  const navigate = useNavigate();

  useEffect(() => { apiGet("/strategies").then((d) => setStrategies(d.strategies)); }, []);

  return (
    <div data-testid="strategy-page">
      <h1 className="text-2xl font-semibold mb-1">Strategy Builder</h1>
      <p className="text-slate-400 text-sm mb-5">10 prebuilt strategies. Click any to generate signals + integrated backtest.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {strategies.map((s) => (
          <button
            key={s.id} onClick={() => navigate("/signals?strategy=" + s.id)}
            className="glass p-5 text-left hover:border-cyan-400 transition"
            data-testid={`strategy-card-${s.id}`}
          >
            <div className="flex justify-between items-center mb-1">
              <span className="text-cyan-300 text-xs uppercase tracking-widest">{s.category}</span>
              <span className="badge badge-hold">Risk {s.risk_score}/5</span>
            </div>
            <div className="font-semibold text-base">{s.name}</div>
            <p className="text-slate-400 text-sm mt-2">{s.description}</p>
            <div className="mt-4 text-xs text-cyan-400">Run signal &rarr;</div>
          </button>
        ))}
      </div>
    </div>
  );
}
