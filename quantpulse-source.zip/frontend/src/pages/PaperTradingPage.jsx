import React, { useEffect, useState } from "react";
import { apiGet, apiPost } from "../lib/api";
import { toast } from "sonner";

const TICKERS = ["AAPL","MSFT","NVDA","GOOGL","AMZN","META","TSLA","RELIANCE.NS","TCS.NS","INFY.NS","HDFCBANK.NS"];

export default function PaperTradingPage() {
  const [portfolio, setPortfolio] = useState(null);
  const [ticker, setTicker] = useState("AAPL");
  const [side, setSide] = useState("BUY");
  const [qty, setQty] = useState(10);
  const [price, setPrice] = useState("");

  const refresh = () => apiGet("/portfolio/paper").then(setPortfolio);
  useEffect(() => { refresh(); }, []);

  const submit = async () => {
    try {
      const body = { ticker, side, quantity: Number(qty) };
      if (price) body.price = Number(price);
      const r = await apiPost("/portfolio/paper/orders", body);
      toast.success(`${r.trade.side} ${r.trade.quantity} ${ticker} @ $${r.trade.price.toFixed(2)}`);
      refresh();
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Order failed");
    }
  };

  const reset = async () => {
    await apiPost("/portfolio/paper/reset", {});
    toast.success("Paper portfolio reset");
    refresh();
  };

  return (
    <div data-testid="paper-trading-page">
      <h1 className="text-2xl font-semibold mb-1">Paper Trading</h1>
      <p className="text-slate-400 text-sm mb-5">Place simulated orders against live yfinance prices.</p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="glass p-5">
          <div className="panel-title">New order</div>
          <div className="grid grid-cols-2 gap-3">
            <select value={ticker} onChange={(e) => setTicker(e.target.value)} className="select" data-testid="pt-ticker">
              {TICKERS.map((t) => <option key={t}>{t}</option>)}
            </select>
            <select value={side} onChange={(e) => setSide(e.target.value)} className="select" data-testid="pt-side">
              <option>BUY</option><option>SELL</option>
            </select>
            <input value={qty} onChange={(e) => setQty(e.target.value)} type="number" min="1" className="input" placeholder="Quantity" data-testid="pt-qty" />
            <input value={price} onChange={(e) => setPrice(e.target.value)} type="number" step="0.01" className="input" placeholder="Price (auto = LTP)" data-testid="pt-price" />
          </div>
          <button onClick={submit} className="btn-primary mt-4 w-full" data-testid="pt-submit">📩 Submit paper order</button>
          <button onClick={reset} className="btn-secondary mt-2 w-full" data-testid="pt-reset">♻️ Reset portfolio</button>
        </div>

        <div className="glass p-5">
          <div className="panel-title">Recent trades</div>
          {!portfolio?.history?.length ? (
            <div className="text-slate-500 text-sm">No trades yet.</div>
          ) : (
            <div className="overflow-y-auto max-h-[360px]">
              <table className="w-full text-sm">
                <thead className="text-slate-400"><tr><th className="text-left py-2">Time</th><th>Symbol</th><th>Side</th><th className="text-right">Qty</th><th className="text-right">Price</th></tr></thead>
                <tbody>
                  {portfolio.history.map((t) => (
                    <tr key={t.id} className="border-t border-[#152150]">
                      <td className="py-2 text-slate-400 text-xs">{new Date(t.timestamp).toLocaleString()}</td>
                      <td className="text-cyan-300">{t.ticker}</td>
                      <td><span className={"badge " + (t.side === "BUY" ? "badge-buy" : "badge-sell")}>{t.side}</span></td>
                      <td className="text-right">{t.quantity}</td>
                      <td className="text-right">${t.price.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
