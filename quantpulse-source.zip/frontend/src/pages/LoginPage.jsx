import React from "react";

export default function LoginPage() {
  const handleLogin = () => {
    // REMINDER: DO NOT HARDCODE THE URL, OR ADD ANY FALLBACKS OR REDIRECT URLS, THIS BREAKS THE AUTH
    const redirectUrl = window.location.origin + "/dashboard";
    window.location.href = `https://auth.emergentagent.com/?redirect=${encodeURIComponent(redirectUrl)}`;
  };

  return (
    <div className="qp-bg flex items-center justify-center px-6 py-12 min-h-screen">
      <div className="glass max-w-md w-full p-10">
        <div className="text-3xl font-bold tracking-tight text-cyan-300" data-testid="login-logo">
          ⚡ QuantPulse
        </div>
        <p className="text-slate-400 mt-2 text-sm">
          Institutional-grade AI algo trading platform.
        </p>

        <ul className="text-slate-300 text-sm mt-8 space-y-2">
          <li>📊 Live charts · 10 indicators</li>
          <li>🤖 AI signal generation (GPT-4o)</li>
          <li>📉 Integrated backtesting</li>
          <li>🔌 Zerodha Kite broker sync</li>
          <li>🛡️ Risk engine + paper trading</li>
        </ul>

        <button
          onClick={handleLogin}
          data-testid="google-login-btn"
          className="mt-10 w-full bg-cyan-500 hover:bg-cyan-400 transition text-slate-900 font-semibold py-3 rounded-lg"
        >
          Sign in with Google
        </button>
        <p className="mt-3 text-[11px] text-slate-500 text-center">
          We never store passwords. Auth handled via Emergent.
        </p>
      </div>
    </div>
  );
}
