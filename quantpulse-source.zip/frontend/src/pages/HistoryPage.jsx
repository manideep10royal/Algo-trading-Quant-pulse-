import React, { useEffect, useState } from "react";
import { apiGet } from "../lib/api";

export default function HistoryPage() {
  const [trades, setTrades] = useState([]);
  useEffect(() => {
    apiGet("/portfolio/paper").then((p) => setTrades(p.history || []));
  }, []);
  return (
    <div data-testid="history-page">
      <h1 className="text-2xl font-semibold mb-1">Trade History</h1>
      <p className="text-slate-400 text-sm mb-5">All paper-trade executions in this account.</p>
      <div className="glass p-5">
        {trades.length === 0 ? (
          <div className="text-slate-500 text-sm">No trades yet.</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="text-slate-400"><tr>
              <th className="text-left py-2">Time</th><th>ID</th><th>Symbol</th>
              <th>Side</th><th className="text-right">Qty</th><th className="text-right">Price</th><th className="text-right">Total</th><th>Mode</th>
            </tr></thead>
            <tbody>
              {trades.map((t) => (
                <tr key={t.id} className="border-t border-[#152150]">
                  <td className="py-2 text-slate-400 text-xs">{new Date(t.timestamp).toLocaleString()}</td>
                  <td className="text-slate-500">{t.id}</td>
                  <td className="text-cyan-300">{t.ticker}</td>
                  <td><span className={"badge " + (t.side === "BUY" ? "badge-buy" : "badge-sell")}>{t.side}</span></td>
                  <td className="text-right">{t.quantity}</td>
                  <td className="text-right">${t.price.toFixed(2)}</td>
                  <td className="text-right">${t.total.toFixed(2)}</td>
                  <td><span className="badge badge-hold">{t.mode}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
