import React, { useEffect, useState } from "react";
import { apiGet } from "../lib/api";
import CandlestickChart from "../components/CandlestickChart";

const TICKERS = ["AAPL","MSFT","NVDA","GOOGL","AMZN","META","TSLA","RELIANCE.NS","TCS.NS","INFY.NS","HDFCBANK.NS","BTC-USD"];

export default function MarketPage() {
  const [ticker, setTicker] = useState("AAPL");
  const [period, setPeriod] = useState("1y");
  const [candles, setCandles] = useState([]);
  const [quote, setQuote] = useState(null);

  useEffect(() => {
    setCandles([]);
    apiGet("/market/candles", { ticker, period }).then((d) => setCandles(d.candles)).catch(() => {});
    apiGet("/market/quote", { ticker }).then(setQuote).catch(() => {});
  }, [ticker, period]);

  return (
    <div data-testid="market-page">
      <div className="flex flex-wrap items-end justify-between gap-3 mb-5">
        <div>
          <h1 className="text-2xl font-semibold">Market Overview</h1>
          <p className="text-slate-400 text-sm">Live OHLCV chart powered by yfinance.</p>
        </div>
        <div className="flex gap-2">
          <select value={ticker} onChange={(e) => setTicker(e.target.value)} className="bg-[#0e1530] border border-[#1f2a4d] rounded px-3 py-2 text-sm" data-testid="market-ticker-select">
            {TICKERS.map((t) => <option key={t}>{t}</option>)}
          </select>
          <select value={period} onChange={(e) => setPeriod(e.target.value)} className="bg-[#0e1530] border border-[#1f2a4d] rounded px-3 py-2 text-sm" data-testid="market-period-select">
            {["1mo","3mo","6mo","1y","2y","5y"].map((p) => <option key={p}>{p}</option>)}
          </select>
        </div>
      </div>

      {quote && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
          <div className="kpi-card"><div className="kpi-label">Last</div><div className="kpi-value">${quote.price.toFixed(2)}</div></div>
          <div className="kpi-card"><div className="kpi-label">Change</div>
            <div className={"kpi-value " + (quote.change >= 0 ? "delta-up" : "delta-down")}>
              {quote.change >= 0 ? "+" : ""}{quote.change.toFixed(2)}
            </div>
          </div>
          <div className="kpi-card"><div className="kpi-label">Change %</div>
            <div className={"kpi-value " + (quote.change_pct >= 0 ? "delta-up" : "delta-down")}>
              {(quote.change_pct * 100).toFixed(2)}%
            </div>
          </div>
          <div className="kpi-card"><div className="kpi-label">Ticker</div><div className="kpi-value text-cyan-300">{quote.ticker}</div></div>
        </div>
      )}

      <div className="glass p-4">
        <div className="panel-title">{ticker} · {period}</div>
        <CandlestickChart candles={candles} height={460} />
      </div>
    </div>
  );
}
