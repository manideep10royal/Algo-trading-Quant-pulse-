import React, { useEffect, useRef } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { apiPost } from "../lib/api";
import { useAuthStore } from "../store/auth";

export default function AuthCallback() {
  const navigate = useNavigate();
  const location = useLocation();
  const setUser = useAuthStore((s) => s.setUser);
  const hasProcessed = useRef(false);

  useEffect(() => {
    if (hasProcessed.current) return;
    hasProcessed.current = true;
    const hash = location.hash || window.location.hash;
    const match = hash.match(/session_id=([^&]+)/);
    if (!match) {
      navigate("/login", { replace: true });
      return;
    }
    const sessionId = match[1];
    (async () => {
      try {
        const user = await apiPost("/auth/google/session", { session_id: sessionId });
        setUser(user);
        // Clear the URL fragment and go to dashboard
        window.history.replaceState(null, "", "/dashboard");
        navigate("/dashboard", { replace: true, state: { user } });
      } catch (e) {
        navigate("/login", { replace: true });
      }
    })();
  }, [location.hash, navigate, setUser]);

  return (
    <div className="qp-bg flex items-center justify-center min-h-screen">
      <div className="text-slate-400 text-sm">Signing you in…</div>
    </div>
  );
}
