import React, { useEffect, useState } from "react";
import { apiGet } from "../lib/api";
import { useNavigate } from "react-router-dom";
import { LineChart, Activity, Wallet, Sparkles } from "lucide-react";

const WATCH = ["AAPL", "MSFT", "NVDA", "TSLA", "GOOGL", "META", "AMZN", "RELIANCE.NS", "TCS.NS"];

export default function DashboardPage() {
  const [quotes, setQuotes] = useState({});
  const [portfolio, setPortfolio] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    apiGet("/portfolio/paper").then(setPortfolio).catch(() => {});
    WATCH.forEach((t) => {
      apiGet("/market/quote", { ticker: t })
        .then((q) => setQuotes((prev) => ({ ...prev, [t]: q })))
        .catch(() => {});
    });
  }, []);

  return (
    <div data-testid="dashboard-page">
      <h1 className="text-2xl font-semibold tracking-tight">Good day, trader.</h1>
      <p className="text-slate-400 text-sm mb-6">Here's your market & portfolio snapshot.</p>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <KPI label="Portfolio Value" value={portfolio ? `$${portfolio.summary.value.toLocaleString(undefined,{maximumFractionDigits:0})}` : "—"}
             sub={portfolio ? `${(portfolio.summary.total_return*100).toFixed(2)}% total` : ""}
             positive={portfolio ? portfolio.summary.total_return >= 0 : true}
             testid="kpi-portfolio-value" />
        <KPI label="Cash"  value={portfolio ? `$${portfolio.cash.toLocaleString(undefined,{maximumFractionDigits:0})}` : "—"}
             sub={portfolio ? `${portfolio.summary.n_positions} positions` : ""}
             testid="kpi-cash" />
        <KPI label="Unrealized P&L" value={portfolio ? `$${portfolio.summary.unrealized_pnl.toLocaleString(undefined,{maximumFractionDigits:0})}` : "—"}
             positive={portfolio ? portfolio.summary.unrealized_pnl >= 0 : true}
             testid="kpi-unrealized" />
        <KPI label="Trades" value={portfolio ? portfolio.summary.n_trades : "—"} testid="kpi-trades" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {[
          { icon: LineChart, t: "Market Overview", d: "Live quotes, charts and AI sentiment for any ticker.", to: "/market" },
          { icon: Activity, t: "Signal Generation", d: "Run any of 10 strategies with integrated backtest + AI rationale.", to: "/signals" },
          { icon: Wallet, t: "Portfolio", d: "Paper trading + Zerodha live sync side-by-side.", to: "/portfolio" },
          { icon: Sparkles, t: "AI Insights", d: "GPT-4o assistant trained on your portfolio data.", to: "/ai-insights" },
        ].map(({ icon: Icon, t, d, to }) => (
          <button key={t} onClick={() => navigate(to)} className="glass p-5 text-left hover:border-cyan-400 transition group" data-testid={`tile-${t.toLowerCase().replace(/[^a-z]/g,'-')}`}>
            <Icon className="text-cyan-300 mb-2" />
            <div className="font-semibold">{t}</div>
            <p className="text-slate-400 text-sm mt-1">{d}</p>
          </button>
        ))}
      </div>

      <div className="glass p-4">
        <div className="panel-title">Watchlist</div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-9 gap-2">
          {WATCH.map((t) => {
            const q = quotes[t];
            return (
              <div key={t} className="kpi-card !p-3" data-testid={`watch-${t}`}>
                <div className="kpi-label">{t}</div>
                <div className="text-lg font-semibold mt-1">{q ? `$${q.price.toFixed(2)}` : "—"}</div>
                {q && (
                  <div className={"text-xs mt-1 " + (q.change_pct >= 0 ? "delta-up" : "delta-down")}>
                    {(q.change_pct * 100).toFixed(2)}%
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function KPI({ label, value, sub, positive = true, testid }) {
  return (
    <div className="kpi-card" data-testid={testid}>
      <div className="kpi-label">{label}</div>
      <div className="kpi-value">{value}</div>
      {sub && <div className={"text-xs mt-1 " + (positive ? "delta-up" : "delta-down")}>{sub}</div>}
    </div>
  );
}
