import React, { useEffect, useState } from "react";
import { apiGet, apiPost } from "../lib/api";
import { toast } from "sonner";

export default function SettingsPage() {
  const [status, setStatus] = useState({ connected: false });
  const [apiKey, setApiKey] = useState("");
  const [apiSecret, setApiSecret] = useState("");
  const [loginUrl, setLoginUrl] = useState("");
  const [reqToken, setReqToken] = useState("");

  const refresh = () => apiGet("/broker/kite/status").then(setStatus);
  useEffect(() => { refresh(); }, []);

  const getLogin = async () => {
    try {
      const r = await apiPost("/broker/kite/login-url", { api_key: apiKey });
      setLoginUrl(r.login_url);
      window.open(r.login_url, "_blank", "noopener");
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Failed to build login URL");
    }
  };

  const connect = async () => {
    try {
      const r = await apiPost("/broker/kite/session", {
        api_key: apiKey, api_secret: apiSecret, request_token: reqToken,
      });
      toast.success(`Connected as ${r.user_name}`);
      refresh();
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Connection failed");
    }
  };

  const disconnect = async () => {
    await apiPost("/broker/kite/disconnect", {});
    refresh(); toast("Disconnected from Zerodha.");
  };

  return (
    <div data-testid="settings-page" className="max-w-3xl">
      <h1 className="text-2xl font-semibold mb-1">Settings</h1>
      <p className="text-slate-400 text-sm mb-5">Connect your broker so live holdings sync into Portfolio.</p>

      <div className="glass p-6">
        <div className="panel-title">Zerodha Kite Connect</div>
        <div className="text-sm text-slate-400 mb-4">
          Status: {status.connected ? <span className="text-emerald-400">✅ Connected as {status.user_name}</span> : <span>❌ Not connected</span>}
        </div>

        {status.connected ? (
          <button className="btn-secondary" onClick={disconnect} data-testid="kite-disconnect-btn">Disconnect</button>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
              <input value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder="Kite API Key" className="input" data-testid="kite-api-key" />
              <input value={apiSecret} onChange={(e) => setApiSecret(e.target.value)} type="password" placeholder="Kite API Secret" className="input" data-testid="kite-api-secret" />
            </div>
            <button onClick={getLogin} disabled={!apiKey} className="btn-secondary mb-3" data-testid="kite-login-btn">🔗 Open Kite Login</button>
            <p className="text-xs text-slate-500 mb-3">After Kite login, copy the <code>request_token=...</code> from the redirect URL and paste below.</p>
            <input value={reqToken} onChange={(e) => setReqToken(e.target.value)} placeholder="Paste request_token" className="input w-full mb-3" data-testid="kite-req-token" />
            <button onClick={connect} disabled={!apiKey || !apiSecret || !reqToken} className="btn-primary w-full" data-testid="kite-connect-btn">
              ✅ Generate session & connect
            </button>
          </>
        )}
      </div>
    </div>
  );
}
