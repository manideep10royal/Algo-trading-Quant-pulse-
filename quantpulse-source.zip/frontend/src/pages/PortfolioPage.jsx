import React, { useEffect, useState } from "react";
import { apiGet } from "../lib/api";
import EquityChart from "../components/EquityChart";

export default function PortfolioPage() {
  const [portfolio, setPortfolio] = useState(null);
  const [live, setLive] = useState({ holdings: [], net: [] });
  const [brokerStatus, setBrokerStatus] = useState({ connected: false });

  useEffect(() => {
    apiGet("/portfolio/paper").then(setPortfolio).catch(() => {});
    apiGet("/broker/kite/status").then(setBrokerStatus).catch(() => {});
  }, []);

  useEffect(() => {
    if (brokerStatus.connected) {
      apiGet("/broker/kite/holdings").then((d) => setLive((p) => ({ ...p, holdings: d.holdings || [] }))).catch(() => {});
      apiGet("/broker/kite/positions").then((d) => setLive((p) => ({ ...p, net: d.net || [] }))).catch(() => {});
    }
  }, [brokerStatus.connected]);

  if (!portfolio) return <div className="text-slate-400">Loading portfolio…</div>;
  const s = portfolio.summary;

  return (
    <div data-testid="portfolio-page">
      <h1 className="text-2xl font-semibold mb-1">Portfolio</h1>
      <p className="text-slate-400 text-sm mb-5">Paper trading + Zerodha live broker sync.</p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        <div className="kpi-card" data-testid="port-value"><div className="kpi-label">Value</div><div className="kpi-value">${s.value.toLocaleString(undefined,{maximumFractionDigits:0})}</div>
          <div className={"text-xs mt-1 " + (s.total_return >= 0 ? "delta-up" : "delta-down")}>{(s.total_return*100).toFixed(2)}%</div>
        </div>
        <div className="kpi-card" data-testid="port-cash"><div className="kpi-label">Cash</div><div className="kpi-value">${portfolio.cash.toLocaleString(undefined,{maximumFractionDigits:0})}</div></div>
        <div className="kpi-card" data-testid="port-pnl"><div className="kpi-label">Unrealized P&L</div><div className={"kpi-value " + (s.unrealized_pnl >= 0 ? "delta-up" : "delta-down")}>${s.unrealized_pnl.toLocaleString(undefined,{maximumFractionDigits:0})}</div></div>
        <div className="kpi-card" data-testid="port-positions"><div className="kpi-label">Positions</div><div className="kpi-value">{s.n_positions}</div></div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-5">
        <div className="glass p-4 lg:col-span-2">
          <div className="panel-title">Equity (current snapshot)</div>
          <EquityChart data={[{ time: Math.floor(Date.now()/1000) - 86400, value: portfolio.initial_capital }, { time: Math.floor(Date.now()/1000), value: s.value }]} height={220} />
        </div>
        <div className="glass p-4">
          <div className="panel-title">Allocation</div>
          {portfolio.positions.length === 0 ? (
            <div className="text-slate-500 text-sm">Place a paper trade to populate allocation.</div>
          ) : (
            <table className="w-full text-sm">
              <tbody>
                <tr><td className="text-slate-400">CASH</td><td className="text-right">${portfolio.cash.toLocaleString(undefined,{maximumFractionDigits:0})}</td></tr>
                {portfolio.positions.map((p) => (
                  <tr key={p.ticker}><td className="text-cyan-300">{p.ticker}</td><td className="text-right">${p.market_value.toLocaleString(undefined,{maximumFractionDigits:0})}</td></tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      <div className="glass p-4 mb-5" data-testid="paper-positions-panel">
        <div className="flex justify-between items-center mb-3">
          <div className="panel-title m-0">Paper positions</div>
          <span className="badge badge-hold">PAPER</span>
        </div>
        {portfolio.positions.length === 0 ? (
          <div className="text-slate-500 text-sm">No positions yet.</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="text-slate-400">
              <tr><th className="text-left py-2">Ticker</th><th className="text-right">Qty</th><th className="text-right">Avg</th><th className="text-right">Last</th><th className="text-right">Market Val</th><th className="text-right">Unrealized</th></tr>
            </thead>
            <tbody>
              {portfolio.positions.map((p) => (
                <tr key={p.ticker} className="border-t border-[#152150]">
                  <td className="py-2 text-cyan-300">{p.ticker}</td>
                  <td className="text-right">{p.quantity}</td>
                  <td className="text-right">${p.avg_price.toFixed(2)}</td>
                  <td className="text-right">${p.last_price.toFixed(2)}</td>
                  <td className="text-right">${p.market_value.toFixed(2)}</td>
                  <td className={"text-right " + (p.unrealized_pnl >= 0 ? "delta-up" : "delta-down")}>${p.unrealized_pnl.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="glass p-4" data-testid="live-positions-panel">
        <div className="flex justify-between items-center mb-3">
          <div className="panel-title m-0">Live Zerodha holdings</div>
          <span className={"badge " + (brokerStatus.connected ? "badge-buy" : "badge-hold")}>
            {brokerStatus.connected ? `LIVE · ${brokerStatus.user_name}` : "NOT CONNECTED"}
          </span>
        </div>
        {!brokerStatus.connected ? (
          <div className="text-slate-500 text-sm">Go to <b>Settings</b> to connect your Zerodha account, then live holdings will appear here.</div>
        ) : live.holdings.length === 0 ? (
          <div className="text-slate-500 text-sm">No holdings reported from Kite.</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="text-slate-400">
              <tr><th className="text-left py-2">Symbol</th><th className="text-right">Qty</th><th className="text-right">Avg</th><th className="text-right">LTP</th><th className="text-right">P&L</th></tr>
            </thead>
            <tbody>
              {live.holdings.map((h, i) => (
                <tr key={i} className="border-t border-[#152150]">
                  <td className="py-2 text-cyan-300">{h.tradingsymbol}</td>
                  <td className="text-right">{h.quantity}</td>
                  <td className="text-right">{h.average_price?.toFixed?.(2) ?? h.average_price}</td>
                  <td className="text-right">{h.last_price?.toFixed?.(2) ?? h.last_price}</td>
                  <td className={"text-right " + ((h.pnl ?? 0) >= 0 ? "delta-up" : "delta-down")}>{h.pnl?.toFixed?.(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
