import React, { useEffect, useState } from "react";
import { apiGet, apiPost } from "../lib/api";
import { useSearchParams } from "react-router-dom";
import EquityChart from "../components/EquityChart";
import { toast } from "sonner";

const TICKERS = ["AAPL","MSFT","NVDA","GOOGL","AMZN","META","TSLA","RELIANCE.NS","TCS.NS","INFY.NS","HDFCBANK.NS"];

export default function SignalsPage() {
  const [strategies, setStrategies] = useState([]);
  const [params] = useSearchParams();
  const [strategyId, setStrategyId] = useState(params.get("strategy") || "sma_cross");
  const [ticker, setTicker] = useState("AAPL");
  const [period, setPeriod] = useState("1y");
  const [result, setResult] = useState(null);
  const [aiText, setAiText] = useState("");
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => { apiGet("/strategies").then((d) => setStrategies(d.strategies)); }, []);

  const run = async () => {
    setLoading(true); setResult(null); setAiText("");
    try {
      const r = await apiPost(`/strategies/${strategyId}/run`, { ticker, period, initial_capital: 100000 });
      setResult(r);
    } catch (e) {
      toast.error("Signal generation failed");
    } finally { setLoading(false); }
  };

  const explain = async () => {
    if (!result) return;
    setAiLoading(true);
    try {
      const r = await apiPost("/ai/insights", {
        ticker, action: result.snapshot.action,
        technical: result.snapshot, ml: result.ml_prediction,
      });
      setAiText(r.text);
    } finally { setAiLoading(false); }
  };

  const placePaper = async (side) => {
    if (!result) return;
    try {
      const r = await apiPost("/portfolio/paper/orders", {
        ticker, side, quantity: result.risk_validation.suggested_quantity || 1,
      });
      toast.success(`${side} ${r.trade.quantity} ${ticker} @ $${r.trade.price.toFixed(2)} (paper)`);
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Order failed");
    }
  };

  const snap = result?.snapshot;
  const ml = result?.ml_prediction;
  const bt = result?.backtest;
  const rv = result?.risk_validation;

  return (
    <div data-testid="signals-page">
      <h1 className="text-2xl font-semibold mb-1">Signal Generation</h1>
      <p className="text-slate-400 text-sm mb-5">Indicators + ML alpha + integrated backtest + risk-checked sizing.</p>

      <div className="glass p-4 mb-5">
        <div className="flex flex-wrap gap-3 items-end">
          <Field label="Strategy">
            <select value={strategyId} onChange={(e) => setStrategyId(e.target.value)} className="select" data-testid="signal-strategy-select">
              {strategies.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </Field>
          <Field label="Ticker">
            <select value={ticker} onChange={(e) => setTicker(e.target.value)} className="select" data-testid="signal-ticker-select">
              {TICKERS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="History">
            <select value={period} onChange={(e) => setPeriod(e.target.value)} className="select" data-testid="signal-period-select">
              {["3mo","6mo","1y","2y","5y"].map((p) => <option key={p}>{p}</option>)}
            </select>
          </Field>
          <button onClick={run} disabled={loading} className="btn-primary" data-testid="run-signal-btn">
            {loading ? "Running…" : "▶︎ Generate signal"}
          </button>
        </div>
      </div>

      {result && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-5">
            <div className="kpi-card" data-testid="signal-action">
              <div className="kpi-label">Final Action</div>
              <div className="kpi-value">
                <span className={"badge " + (snap.action === "BUY" ? "badge-buy" : snap.action === "SELL" ? "badge-sell" : "badge-hold")}>{snap.action}</span>
              </div>
              <div className="text-xs text-slate-500 mt-1">Vote {snap.vote}</div>
            </div>
            <div className="kpi-card" data-testid="signal-ml-action">
              <div className="kpi-label">ML Prediction</div>
              <div className="kpi-value">
                <span className={"badge " + (ml.action === "BUY" ? "badge-buy" : ml.action === "SELL" ? "badge-sell" : "badge-hold")}>{ml.action}</span>
              </div>
              <div className="text-xs text-slate-500 mt-1">Conf {(ml.confidence*100).toFixed(1)}%</div>
            </div>
            <div className="kpi-card"><div className="kpi-label">Buy / Sell prob</div>
              <div className="kpi-value text-base">{(ml.buy_probability*100).toFixed(0)}% / {(ml.sell_probability*100).toFixed(0)}%</div>
              <div className="text-xs text-slate-500 mt-1">Backtest acc {(ml.accuracy*100).toFixed(1)}%</div>
            </div>
            <div className="kpi-card" data-testid="signal-risk">
              <div className="kpi-label">Risk sizing</div>
              <div className="kpi-value text-base">{rv.suggested_quantity} sh</div>
              <div className="text-xs text-slate-500 mt-1">SL ${rv.stop_loss} · TP ${rv.take_profit}</div>
            </div>
            <div className="kpi-card"><div className="kpi-label">R:R</div>
              <div className="kpi-value">1 : {rv.risk_reward_ratio.toFixed(2)}</div>
              <div className={"text-xs mt-1 " + (rv.is_valid ? "delta-up" : "delta-down")}>{rv.is_valid ? "valid" : "blocked"}</div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-5">
            <div className="glass p-4 lg:col-span-2">
              <div className="panel-title">Integrated backtest equity curve</div>
              <EquityChart data={bt.equity_curve} height={300} />
              <div className="grid grid-cols-3 md:grid-cols-6 gap-3 mt-3">
                <Metric label="Final"  value={`$${bt.final_equity.toLocaleString(undefined,{maximumFractionDigits:0})}`} />
                <Metric label="Return" value={`${(bt.total_return*100).toFixed(2)}%`} positive={bt.total_return >= 0} />
                <Metric label="CAGR"   value={`${(bt.cagr*100).toFixed(2)}%`} positive={bt.cagr >= 0} />
                <Metric label="Sharpe" value={bt.sharpe.toFixed(2)} />
                <Metric label="Max DD" value={`${(bt.max_drawdown*100).toFixed(2)}%`} positive={false} />
                <Metric label="Trades" value={bt.n_trades} />
              </div>
            </div>
            <div className="glass p-4 flex flex-col">
              <div className="panel-title">AI Rationale</div>
              <button onClick={explain} disabled={aiLoading} className="btn-secondary mb-3" data-testid="ai-explain-btn">
                {aiLoading ? "GPT-4o thinking…" : "🪄 Generate explanation"}
              </button>
              <div className="text-sm text-slate-300 whitespace-pre-wrap flex-1" data-testid="ai-rationale-text">
                {aiText || <span className="text-slate-500">Click the button to get a GPT-4o trade rationale.</span>}
              </div>
            </div>
          </div>

          <div className="glass p-4 flex flex-wrap gap-3 items-center justify-between" data-testid="signal-action-bar">
            <div className="text-sm text-slate-400">Place a paper trade based on this signal:</div>
            <div className="flex gap-2">
              <button className="btn-buy"  onClick={() => placePaper("BUY")}  data-testid="paper-buy-btn">BUY {ticker}</button>
              <button className="btn-sell" onClick={() => placePaper("SELL")} data-testid="paper-sell-btn">SELL {ticker}</button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div className="flex flex-col gap-1">
      <span className="text-[11px] text-slate-500 uppercase tracking-widest">{label}</span>
      {children}
    </div>
  );
}
function Metric({ label, value, positive = true }) {
  return (
    <div>
      <div className="text-[11px] text-slate-500 uppercase tracking-widest">{label}</div>
      <div className={"text-base font-semibold " + (positive ? "delta-up" : "delta-down")}>{value}</div>
    </div>
  );
}
