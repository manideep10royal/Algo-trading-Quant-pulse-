import React, { useEffect, useState } from "react";
import { apiGet } from "../lib/api";
import { Link2 } from "lucide-react";
import { NavLink } from "react-router-dom";

export default function BrokerStatus() {
  const [status, setStatus] = useState(null);

  useEffect(() => {
    apiGet("/broker/kite/status").then(setStatus).catch(() => {});
  }, []);

  const connected = status?.connected;
  return (
    <div className="glass p-3" data-testid="broker-status">
      <div className="flex items-center gap-2 text-[11px] uppercase tracking-widest text-slate-500">
        <Link2 size={12} /> Broker
      </div>
      <div className="mt-1 text-sm">
        {connected ? (
          <span className="text-emerald-400" data-testid="broker-connected">✅ {status.user_name}</span>
        ) : (
          <span className="text-slate-400" data-testid="broker-disconnected">❌ Not connected</span>
        )}
      </div>
      {!connected && (
        <NavLink to="/settings" className="text-cyan-400 text-xs mt-1 inline-block" data-testid="connect-broker-link">
          Connect Zerodha →
        </NavLink>
      )}
    </div>
  );
}
