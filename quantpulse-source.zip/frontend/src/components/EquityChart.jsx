import React, { useEffect, useRef } from "react";
import { createChart, ColorType, AreaSeries } from "lightweight-charts";

export default function EquityChart({ data, height = 260 }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current) return;
    const chart = createChart(ref.current, {
      width: ref.current.clientWidth, height,
      layout: { background: { type: ColorType.Solid, color: "#0b1020" }, textColor: "#94a3b8" },
      grid: { vertLines: { color: "#152150" }, horzLines: { color: "#152150" } },
      timeScale: { timeVisible: true, secondsVisible: false, borderColor: "#1f2a4d" },
      rightPriceScale: { borderColor: "#1f2a4d" },
      localization: { locale: "en-US" },
    });
    const series = chart.addSeries(AreaSeries, {
      lineColor: "#22d3ee", topColor: "rgba(34,211,238,0.35)",
      bottomColor: "rgba(34,211,238,0.02)", lineWidth: 2,
    });
    if (data?.length) {
      series.setData(data);
      chart.timeScale().fitContent();
    }
    const onResize = () => chart.applyOptions({ width: ref.current.clientWidth });
    window.addEventListener("resize", onResize);
    return () => { window.removeEventListener("resize", onResize); chart.remove(); };
  }, [data, height]);
  return <div ref={ref} style={{ width: "100%", height }} data-testid="equity-chart" />;
}
