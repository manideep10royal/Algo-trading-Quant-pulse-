import React, { useEffect, useRef } from "react";
import { createChart, ColorType, CrosshairMode, CandlestickSeries } from "lightweight-charts";

export default function CandlestickChart({ candles, height = 380 }) {
  const containerRef = useRef(null);
  const chartRef = useRef(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const chart = createChart(containerRef.current, {
      width: containerRef.current.clientWidth,
      height,
      layout: { background: { type: ColorType.Solid, color: "#0b1020" }, textColor: "#94a3b8" },
      grid: { vertLines: { color: "#152150" }, horzLines: { color: "#152150" } },
      crosshair: { mode: CrosshairMode.Normal },
      timeScale: { timeVisible: true, secondsVisible: false, borderColor: "#1f2a4d" },
      rightPriceScale: { borderColor: "#1f2a4d" },
      localization: { locale: "en-US" },
    });
    const series = chart.addSeries(CandlestickSeries, {
      upColor: "#22c55e", downColor: "#ef4444",
      borderUpColor: "#22c55e", borderDownColor: "#ef4444",
      wickUpColor: "#22c55e", wickDownColor: "#ef4444",
    });
    chartRef.current = { chart, series };

    const onResize = () => chart.applyOptions({ width: containerRef.current.clientWidth });
    window.addEventListener("resize", onResize);
    return () => { window.removeEventListener("resize", onResize); chart.remove(); };
  }, [height]);

  useEffect(() => {
    if (!chartRef.current || !candles?.length) return;
    chartRef.current.series.setData(candles);
    chartRef.current.chart.timeScale().fitContent();
  }, [candles]);

  return <div ref={containerRef} style={{ width: "100%", height }} data-testid="candlestick-chart" />;
}
