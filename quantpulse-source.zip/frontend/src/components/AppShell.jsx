import React, { useEffect } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import {
  LayoutDashboard, LineChart, Wallet, Wrench, Activity,
  ClipboardList, ShieldAlert, Sparkles, History, Settings, LogOut,
} from "lucide-react";
import { useAuthStore } from "../store/auth";
import BrokerStatus from "./BrokerStatus";

const NAV = [
  { to: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/market", icon: LineChart, label: "Market Overview" },
  { to: "/portfolio", icon: Wallet, label: "Portfolio" },
  { to: "/strategy", icon: Wrench, label: "Strategy Builder" },
  { to: "/signals", icon: Activity, label: "Signal Generation" },
  { to: "/paper-trading", icon: ClipboardList, label: "Paper Trading" },
  { to: "/risk", icon: ShieldAlert, label: "Risk Management" },
  { to: "/ai-insights", icon: Sparkles, label: "AI Insights" },
  { to: "/history", icon: History, label: "Trade History" },
  { to: "/settings", icon: Settings, label: "Settings" },
];

export default function AppShell() {
  const { user, loading, checkAuth, logout } = useAuthStore();
  const navigate = useNavigate();

  useEffect(() => { checkAuth(); }, [checkAuth]);

  useEffect(() => {
    if (!loading && !user) navigate("/login", { replace: true });
  }, [user, loading, navigate]);

  if (loading) return <div className="qp-bg flex items-center justify-center min-h-screen text-slate-400">Loading…</div>;
  if (!user) return null;

  return (
    <div className="qp-bg flex">
      <aside className="w-64 shrink-0 border-r border-[#152150] p-4 sticky top-0 h-screen overflow-y-auto" data-testid="sidebar">
        <div className="text-xl font-bold text-cyan-300 mb-1">⚡ QuantPulse</div>
        <div className="text-[11px] uppercase tracking-widest text-slate-500 mb-5">algo trading</div>

        {/* user card */}
        <div className="glass p-3 mb-5 flex items-center gap-3" data-testid="sidebar-user-card">
          {user.picture ? (
            <img src={user.picture} alt="" className="w-9 h-9 rounded-full object-cover" />
          ) : (
            <div className="w-9 h-9 rounded-full bg-cyan-500/30 flex items-center justify-center text-cyan-300 font-bold">
              {user.name?.[0]?.toUpperCase() || "?"}
            </div>
          )}
          <div className="min-w-0">
            <div className="text-sm font-semibold truncate" data-testid="user-name">{user.name}</div>
            <div className="text-[11px] text-slate-500 truncate" data-testid="user-email">{user.email}</div>
          </div>
        </div>

        <BrokerStatus />

        <nav className="mt-5 space-y-1">
          {NAV.map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to} to={to}
              className={({ isActive }) => "sidebar-link" + (isActive ? " active" : "")}
              data-testid={`nav-${label.toLowerCase().replace(/[^a-z]/g, "-")}`}
            >
              <Icon size={16} /> {label}
            </NavLink>
          ))}
        </nav>

        <button
          onClick={() => { logout().then(() => navigate("/login", { replace: true })); }}
          className="mt-6 w-full sidebar-link text-rose-400 hover:!text-rose-300"
          data-testid="logout-btn"
        >
          <LogOut size={16} /> Sign out
        </button>
      </aside>

      <main className="flex-1 min-h-screen p-6 md:p-8 overflow-x-hidden">
        <Outlet />
      </main>
    </div>
  );
}
